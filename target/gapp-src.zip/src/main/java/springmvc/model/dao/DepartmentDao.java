package springmvc.model.dao;

import java.util.List;

import springmvc.model.Department;



public interface DepartmentDao {

	 List<Department> getDepartment();

	Department getdepartmentByID(int id);

	Department addDepartment(Department department);

	void saveDepartment(Department department);
	
}
