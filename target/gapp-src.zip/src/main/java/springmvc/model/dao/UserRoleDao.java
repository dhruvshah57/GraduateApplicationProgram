package springmvc.model.dao;

import springmvc.model.User_Role;

public interface UserRoleDao {

	User_Role getRoleById(int id);

}
