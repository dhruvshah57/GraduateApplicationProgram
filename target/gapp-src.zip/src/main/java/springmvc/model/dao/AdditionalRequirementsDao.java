package springmvc.model.dao;

import java.util.List;

import springmvc.model.AdditionalRequirements;
import springmvc.model.Programs;

public interface AdditionalRequirementsDao {
	 List<AdditionalRequirements> getAdditionalRequirements();

	List<AdditionalRequirements> getAdditionalRequirementsByDepartmentId(int dpmtId);
	AdditionalRequirements addreq(AdditionalRequirements addreq);
	}
