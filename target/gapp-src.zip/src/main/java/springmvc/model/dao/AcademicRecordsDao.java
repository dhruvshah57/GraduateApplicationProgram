package springmvc.model.dao;

import springmvc.model.AcademicRecords;

public interface AcademicRecordsDao {


	AcademicRecords addAcademicRecords(AcademicRecords acadrecords);

	AcademicRecords getStudentByUserID(int studentId);

}
